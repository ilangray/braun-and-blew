Step 1: Start the server.

    ./serve.sh

Step 2: Navigate your browser to http://localhost:8888. (Use Chrome unless you're experienced in web dev and prefer another.)

Congratulations.
